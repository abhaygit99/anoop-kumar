<?php

$dbservername = "localhost:3308";
$dbusername = "root";
$dbpassword = "";
$dbName = "housedetails";
$dbtable = "rentaldetails";

$conn = mysqli_connect($dbservername, $dbusername, $dbpassword, $dbName);



?>